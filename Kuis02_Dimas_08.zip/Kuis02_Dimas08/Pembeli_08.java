package Kuis02_Dimas08;

public class Pembeli_08 {
    // atribbut
    String namaPembeli08;
    String nomorHp08;

    // constructor
    Pembeli_08() {

    }
    // parameter
    Pembeli_08(String nama, String no) {
       namaPembeli08 = nama;
       nomorHp08 = no;
    }
}
