package Kuis02_Dimas08;

public class Pesanan_08 {
    // atributz
    int kodePesanan08, harga08;
    String namaPesanan08;
    // constructor
    Pesanan_08() {

    }
    // parameter
    Pesanan_08(int kodePesanan, String namaPesanan, int harga) {
        this.kodePesanan08 = kodePesanan;
        this.namaPesanan08 = namaPesanan;
        this.harga08 = harga;
    }
}
